#!/bin/sh

./bootstrap && ./configure $*
